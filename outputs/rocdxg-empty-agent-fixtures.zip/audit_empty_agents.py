"""CPU-only CLI contract probe with injected inert inventory backend."""
from pathlib import Path
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import subprocess
import sys
import types

root=Path(__file__).resolve().parent
source=root/'cli-source/rocprofv3-avail.py'
raw=source.read_bytes()
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()=='bcfb251c5daad1b171f667abad7276e37dd0a9d1'
if len(sys.argv)==1:
    results=[]
    for case in ['empty','cpu_only','gpu_control','unmatched_device']:
        run=subprocess.run([sys.executable,'-I',str(Path(__file__).resolve()),case],check=True,capture_output=True,text=True,timeout=5)
        results.append(json.loads(run.stdout))
    assert [r['stdout_nonempty'] for r in results]==[False,False,True,False]
    assert all(r['effective_exit_code']==0 for r in results)
    report={'scope':'unmodified pinned CLI main() with fake Python inventory backend; no real profiler/runtime/GPU',
            'source_blob':'bcfb251c5daad1b171f667abad7276e37dd0a9d1',
            'python':sys.version.split()[0],'cases':results,
            'interpretation':'Silent success is a CLI-layer contract observation conditional on backend returning an empty inventory; does not prove actual backend returns empty without diagnostics.'}
    (root/'empty-agent-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
    raise SystemExit(0)

case=sys.argv[1]
tree=ast.parse(raw)
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='get_basic_agent_info')
keys=next(ast.literal_eval(n.value) for n in function.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='req_keys' for t in n.targets))
info={key:0 for key in keys}
info.update(type=2,logical_node_type_id=0,name='synthetic-gfx1101')
inventory={} if case=='empty' else ({0:{'type':1}} if case=='cpu_only' else {0:info})
backend=types.ModuleType('rocprofv3.avail')
backend.get_agent_info_map=lambda:inventory
backend.get_counters=lambda:{}
backend.loadLibrary=lambda:None
package=types.ModuleType('rocprofv3')
package.avail=backend
sys.modules['rocprofv3']=package
sys.modules['rocprofv3.avail']=backend
spec=importlib.util.spec_from_file_location('pinned_avail_cli',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
out,err=io.StringIO(),io.StringIO()
argv=['-d','99','list','--agent'] if case=='unmatched_device' else ['list','--agent']
with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
    result=module.main(argv)
print(json.dumps({'case':case,'argv':argv,'effective_exit_code':0 if result is None else result,
                  'stdout_nonempty':bool(out.getvalue()),'stderr_nonempty':bool(err.getvalue()),
                  'control_gpu_marker':('synthetic-gfx1101' in out.getvalue())}))
