"""Actual pinned active_hsa_runtime_dir with private inert ELF fixtures only."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path(__file__).resolve().parent
raw = (root/'pr13576/dxg_topology.cpp').read_bytes()
oid = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert oid == 'e730ea33a068f9610c5ee2b49ddedb67d1ed3dc0'
cpp = raw.decode()
start = cpp.index('std::string\nactive_hsa_runtime_dir()')
begin = cpp.index('{',start)
depth, end = 1, begin+1
while depth:
    depth += (cpp[end]=='{')-(cpp[end]=='}')
    end += 1
helper = cpp[start:end]
build = root/'runtime-dir-build'
build.mkdir(exist_ok=True)
source = build/'inert.cpp'
source.write_text('extern "C" int inert_fixture_marker() { return 42; }\n')
for sub, name in [('valid','libhsa-runtime64.so.1'),('decoy','libhsa-runtime64.so.backup')]:
    folder=build/sub
    folder.mkdir(exist_ok=True)
    subprocess.run(['g++','-shared','-fPIC',str(source),'-o',str(folder/name)],check=True,timeout=30)
alias=build/'valid/libhsa-runtime64.so'
if not alias.exists(): alias.symlink_to('libhsa-runtime64.so.1')
program = r'''
#include <dlfcn.h>
#include <link.h>
#include <string>
#include <string_view>
#include <vector>
#include <iostream>
__HELPER__
int main(int argc,char** argv) {
 std::vector<void*> handles;
 for(int i=2;i<argc;++i) {
   void* h=dlopen(argv[i],RTLD_NOW|RTLD_LOCAL);
   if(!h) return 10;
   auto marker=reinterpret_cast<int(*)()>(dlsym(h,"inert_fixture_marker"));
   if(!marker || marker()!=42) return 11;
   handles.push_back(h);
 }
 auto actual=active_hsa_runtime_dir();
 bool match=actual==argv[1];
 std::cout<<"{\"expected_directory_selected\":"<<(match?"true":"false")
          <<",\"empty\":"<<(actual.empty()?"true":"false")<<"}"<<std::endl;
 for(auto h:handles) dlclose(h);
}
'''.replace('__HELPER__',helper)
runner=build/'runtime_dir_test.cpp'
runner.write_text(cpp.split('#include',1)[0]+program)
binary=build/'runtime_dir_test'
subprocess.run(['g++','-std=c++17','-Wall','-Wextra',str(runner),'-ldl','-o',str(binary)],check=True,timeout=30,capture_output=True)
valid=str(build/'valid')+'/'
decoy=str(build/'decoy')+'/'
cases=[
 ('none','',[]),
 ('absolute',valid,[valid+'libhsa-runtime64.so.1']),
 ('bare_name_absolute_search_dir',valid,['libhsa-runtime64.so.1']),
 ('relative_load','valid/',['valid/libhsa-runtime64.so.1']),
 ('absolute_symlink',valid,[valid+'libhsa-runtime64.so']),
 ('prefix_decoy_only','',[decoy+'libhsa-runtime64.so.backup']),
 ('prefix_decoy_before_valid',valid,[decoy+'libhsa-runtime64.so.backup',valid+'libhsa-runtime64.so.1']),
]
env=os.environ.copy()
for key in ['LD_PRELOAD','LD_AUDIT','LD_DEBUG','LD_DEBUG_OUTPUT']:
    env.pop(key,None)
env['LD_LIBRARY_PATH']=str(build/'valid')
results=[]
for case,expected,paths in cases:
    # Bare names must exist in our exclusive search directory before use.
    for path in paths:
        assert (Path(path) if Path(path).is_absolute() else (build/path if '/' in path else build/'valid'/path)).is_file()
    started=time.monotonic()
    run=subprocess.run([str(binary),expected,*paths],env=env,cwd=build,capture_output=True,text=True,check=True,timeout=5)
    row=json.loads(run.stdout)
    row.update(case=case,elapsed_ms=round(1000*(time.monotonic()-started),2))
    results.append(row)
    assert row['expected_directory_selected'] == (not case.startswith('prefix_decoy')), row
summary={'scope':'actual extracted PR13576 active_hsa_runtime_dir, real dl_iterate_phdr over private inert ELF fixtures; no AMD libraries or GPU access',
         'source_blob':oid,'pr_head':'65313194df87e824f2d3a3cd8f13dbcc22f8707a',
         'interpretation':'Five ordinary cases pass. Two synthetic prefix-decoy cases demonstrate broad prefix matching; no installed-stack evidence or new ROCm defect claim.',
         'cases':results}
(root/'runtime-dir-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
