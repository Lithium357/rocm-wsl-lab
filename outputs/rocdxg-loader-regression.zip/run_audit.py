"""CPU-only regression audit of pinned upstream RocdxgHandle loader policy.

No AMD library is loaded: every open is redirected to a private stand-in ELF.
The constructor under test is extracted verbatim; resolver/topology are stubs.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

root = Path(__file__).resolve().parent
expected = {"dxg_topology.cpp":"ad716825a4a4b8c81bbcb926cf83cc7ddd4bbdde",
            "dxg_thunk.hpp":"dceb8e885c2af624448eb36b245747f780c0ffcf"}
for name, oid in expected.items():
    raw=(root/"upstream"/name).read_bytes()
    assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==oid, name
original_cpp = (root/"upstream/dxg_topology.cpp").read_text()
original_hpp = (root/"upstream/dxg_thunk.hpp").read_text()
old = '''        handle = ops.open(kLibRocdxgSoname, RTLD_NOW | RTLD_LOCAL | RTLD_NOLOAD);
        if(!handle) handle = ops.open(kLibRocdxgSoname, RTLD_NOW | RTLD_LOCAL);'''
new = '''        // Match ROCr's versioned-first lookup; retain old external packages.
        for(const auto* soname : {kLibRocdxgVersionedSoname, kLibRocdxgSoname})
        {
            handle = ops.open(soname, RTLD_NOW | RTLD_LOCAL | RTLD_NOLOAD);
            if(!handle) handle = ops.open(soname, RTLD_NOW | RTLD_LOCAL);
            if(handle) break;
        }'''
assert original_cpp.count(old) == 1
assert original_hpp.count('inline constexpr const char* kLibRocdxgSoname = "librocdxg.so";') == 1
patched_cpp = original_cpp.replace(old,new)
start = original_hpp.index("// The unversioned soname,")
end = original_hpp.index('\n', original_hpp.index('inline constexpr const char* kLibRocdxgSoname',start))
patched_hpp = original_hpp[:start] + '''// Match ROCr's versioned-first lookup, with the unversioned name as fallback.
inline constexpr const char* kLibRocdxgVersionedSoname = "librocdxg.so.1";
inline constexpr const char* kLibRocdxgSoname = "librocdxg.so";''' + original_hpp[end:]
for name,text in [("dxg_topology.cpp",patched_cpp),("dxg_thunk.hpp",patched_hpp)]:
    folder=root/"patched"
    folder.mkdir(exist_ok=True)
    (folder/name).write_text(text)
patch = ""
for name,before,after in [("dxg_topology.cpp",original_cpp,patched_cpp),("dxg_thunk.hpp",original_hpp,patched_hpp)]:
    path="projects/rocprofiler-sdk/source/lib/rocprofiler-sdk/platform/wsl/"+name
    patch += "".join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile="a/"+path,tofile="b/"+path))
(root/"versioned-first.patch").write_text(patch)

build=root/"build"
build.mkdir(exist_ok=True)
stub=build/"standin.cpp"
stub.write_text('extern "C" int harmless_rocdxg_marker() { return 42; }\n')
broken=build/"broken.cpp"
broken.write_text('extern "C" int unrelated_marker() { return 0; }\n')
fixtures={}
for name, filename, source in [
    ("versioned_only","librocdxg.so.1",stub),
    ("with_alias","librocdxg.so.1",stub),
    ("legacy_only","librocdxg.so",stub),
    ("missing_exports","librocdxg.so",broken)]:
    directory=build/name
    directory.mkdir(exist_ok=True)
    subprocess.run(["g++","-shared","-fPIC",str(source),"-Wl,-soname,"+filename,"-o",str(directory/filename)],check=True)
    fixtures[name]=directory
alias=fixtures["with_alias"]/"librocdxg.so"
if not alias.exists(): alias.symlink_to("librocdxg.so.1")
(build/"missing").mkdir(exist_ok=True)

ops_start=original_hpp.index("struct DxgLoaderOps\n{")
ops=original_hpp[ops_start:original_hpp.index("\n};",ops_start)+3]
scaffold=r'''
#include <dlfcn.h>
#include <filesystem>
#include <functional>
#include <iostream>
#include <string>
#include <vector>
#include <initializer_list>
namespace fmt { template<typename... A> std::string format(const char* s,A&&...) { return s; } }
#define ROCP_WARNING std::cerr
struct DxgThunk { bool found=false; bool complete() const { return found; } };
__OPS__
DxgThunk resolve_dxg_thunk(void* h,const DxgLoaderOps& ops) {
 return {ops.sym(h,"harmless_rocdxg_marker") != nullptr};
}
__CONSTANTS__
__CONSTRUCTOR__
int main(int argc,char** argv) {
 std::filesystem::path private_root=argv[1];
 const std::string scenario=argv[2];
 int opens=0,closes=0;
 std::vector<std::string> requests;
 void* resident=nullptr;
 if(scenario=="resident_versioned_only") {
   resident=dlopen((private_root/"librocdxg.so.1").c_str(),RTLD_NOW|RTLD_LOCAL);
   if(!resident) return 3;
 }
 const DxgLoaderOps ops{
  [&](const char* name,int flags)->void* {
    const std::string basename=name;
    if(basename!="librocdxg.so" && basename!="librocdxg.so.1") return nullptr;
    requests.push_back(basename);
    // Absolute private paths prevent any system or production-library fallback.
    void* h=dlopen((private_root/basename).c_str(),flags);
    if(h) ++opens;
    return h;
  },
  [](void* h,const char* name){return dlsym(h,name);},
  [&](void* h){++closes;return dlclose(h);},
  [](){return dlerror();}
 };
 bool ready=false;
 { const RocdxgHandle handle{ops}; ready=handle.ready(); }
 if(resident) dlclose(resident);
 const bool expected=scenario!="missing" && scenario!="missing_exports";
 std::cout<<"{\"scenario\":\""<<scenario<<"\",\"ready\":"<<(ready?"true":"false")
          <<",\"expected_ready\":"<<(expected?"true":"false")
          <<",\"opens\":"<<opens<<",\"closes\":"<<closes
          <<",\"balanced\":"<<(opens==closes?"true":"false")<<",\"requests\":[";
 for(size_t i=0;i<requests.size();++i){if(i)std::cout<<",";std::cout<<"\""<<requests[i]<<"\"";}
 std::cout<<"]}"<<std::endl;
 return opens==closes?0:4;
}
'''

results=[]
for variant,cpp,hpp in [("upstream",original_cpp,original_hpp),("candidate",patched_cpp,patched_hpp)]:
    begin=cpp.index("struct RocdxgHandle\n{")
    constructor=cpp[begin:cpp.index("\n};",begin)+3]
    constants="\n".join(line for line in hpp.splitlines() if line.startswith("inline constexpr const char* kLibRocdxg"))
    code=scaffold.replace("__OPS__",ops).replace("__CONSTANTS__",constants).replace("__CONSTRUCTOR__",constructor)
    source=build/(variant+"_test.cpp")
    source.write_text(original_cpp.split("#include",1)[0]+code)
    binary=build/(variant+"_test")
    subprocess.run(["g++","-std=c++17","-O2",str(source),"-ldl","-o",str(binary)],check=True)
    for scenario in ["versioned_only","resident_versioned_only","with_alias","legacy_only","missing","missing_exports"]:
        directory=build/("versioned_only" if scenario=="resident_versioned_only" else scenario)
        run=subprocess.run([str(binary),str(directory),scenario],capture_output=True,text=True,check=True,timeout=5)
        result=json.loads(run.stdout)
        result["variant"]=variant
        results.append(result)
        if variant=="candidate": assert result["ready"]==result["expected_ready"],result
        if variant=="upstream":
            expected_observed=False if scenario in ["versioned_only","resident_versioned_only"] else result["expected_ready"]
            assert result["ready"]==expected_observed,result
summary={"scope":"extracted upstream constructor with private stand-in ELF; no GPU, AMD runtime or topology test",
         "source_cpp_blob":"ad716825a4a4b8c81bbcb926cf83cc7ddd4bbdde",
         "source_hpp_blob":"dceb8e885c2af624448eb36b245747f780c0ffcf",
         "cases":results,
         "upstream_contract_failures":sum(x["ready"]!=x["expected_ready"] for x in results if x["variant"]=="upstream"),
         "candidate_contract_failures":sum(x["ready"]!=x["expected_ready"] for x in results if x["variant"]=="candidate")}
(root/"results.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({k:v for k,v in summary.items() if k!="cases"}))
