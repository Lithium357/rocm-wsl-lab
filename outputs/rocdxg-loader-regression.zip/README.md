# CPU-only ROCDXG loader regression

FOLLOW-UP: the local candidate is incomplete. Existing upstream PR #13576
(open, unmerged on 2026-10-28 UTC) handles resident-library reuse and adjacent
runtime lookup more fully. See outputs/rocdxg-loader-audit.md in the task.
Do not apply the historical versioned-first.patch to an installed runtime.
Its six original cases miss two important policy cases; compare_pr13576.py
in the retained work folder documents these using inert loader maps.

Run on Linux/WSL with Python 3 and g++:

```bash
python3 run_audit.py
```

The script compiles private harmless stand-in ELF libraries and extracts the
RocdxgHandle constructor verbatim from the pinned upstream files. It tests the
upstream and candidate constructors against six loader scenarios each. Every
library open is redirected to the private fixture directory. It does not load
AMD libraries, open /dev/dxg, run kernels, attach a profiler, or modify installed
packages. This can run while a separate GPU workload is active.

Expected: upstream has two loader contract failures; the candidate has zero.
Both reject absent libraries/missing exports, and every acquired handle closes.
The resolver is a minimal marker stub, so this is not an end-to-end profiler,
ABI, topology, or GPU trace test. The source-level result supports existing
ROCm/rocm-systems issue 12495, not a claim of a novel hardware defect.

Outputs: results.json, versioned-first.patch, and temporary build artifacts.
Original MIT notices remain in upstream source files. The candidate patch is
not installed or submitted upstream. A complete rocprofiler build/test and a
real profiling run on a compatible isolated stack remain outstanding.

Pinned Git blob IDs:
- dxg_topology.cpp: ad716825a4a4b8c81bbcb926cf83cc7ddd4bbdde
- dxg_thunk.hpp: dceb8e885c2af624448eb36b245747f780c0ffcf
