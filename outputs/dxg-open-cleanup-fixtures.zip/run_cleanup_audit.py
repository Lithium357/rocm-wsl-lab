"""Extract actual upstream open function; all OS/loader effects are inert stubs."""
from pathlib import Path
import hashlib
import json
import subprocess

root=Path(__file__).resolve().parent
pins={'baseline':'68b051017441e32a158901cb63719d59e50576ee',
      'proposed':'4e7c623aee1d6d09861d25cac9bda881ada0b9be'}
scaffold=r'''
#include <mutex>
#include <set>
#include <string>
#include <iostream>
#include <fcntl.h>
using HSAKMT_STATUS=int;
constexpr int HSAKMT_STATUS_SUCCESS=0,HSAKMT_STATUS_ERROR=1,
 HSAKMT_STATUS_KERNEL_IO_CHANNEL_NOT_OPENED=2,HSAKMT_STATUS_KERNEL_ALREADY_OPENED=3;
#define HSAKMTAPI
struct HsaSystemProperties {};
struct Runtime { std::recursive_mutex hsakmt_mutex; int dxg_open_count=0,dxg_fd=-1; const char* dxg_device_name="inert-device"; };
Runtime runtime;
Runtime* dxg_runtime=&runtime;
bool loader_success=true,open_success=true;
int opens=0,closes=0,bad_closes=0,resets=0,next_fd=40;
std::set<int> live;
int fake_open(const char*,int) { ++opens; if(!open_success)return -1; live.insert(++next_fd); return next_fd; }
int fake_close(int fd) { ++closes; if(!live.erase(fd)) ++bad_closes; return 0; }
int fake_atfork(void(*)(),void(*)(),void(*)()) { return 0; }
#define open fake_open
#define close fake_close
#define pthread_atfork fake_atfork
#define pr_err(...) ((void)0)
bool is_forked_child(){return false;}
void clear_after_fork(){}
int init_vars_from_env(){return HSAKMT_STATUS_SUCCESS;}
void init_page_size(){}
void reset_suballocator(){++resets;}
void prepare_fork_handler(){}
void parent_fork_handler(){}
void child_fork_handler(){}
namespace wsl { namespace thunk { namespace dxcore {
struct DxcoreLoader {
 static DxcoreLoader& Instance(){ static DxcoreLoader value;return value; }
 bool Initialize(){return loader_success;}
};
}}}
__FUNCTION__
int main(int argc,char** argv){
 const std::string scenario=argv[1];
 if(scenario=="existing_fd_failure") {runtime.dxg_fd=17;live.insert(17);}
 if(scenario=="already_open") {runtime.dxg_fd=17;live.insert(17);runtime.dxg_open_count=1;}
 if(scenario=="open_failure")open_success=false;
 if(scenario=="loader_failure" || scenario=="existing_fd_failure" || scenario=="failure_then_recover")loader_success=false;
 int first=hsaKmtOpenKFD();
 int fd_after_first=runtime.dxg_fd;
 bool pass=true;
 if(scenario=="loader_failure" || scenario=="existing_fd_failure" || scenario=="failure_then_recover")
   pass=first==HSAKMT_STATUS_ERROR && runtime.dxg_fd==-1 && runtime.dxg_open_count==0 && live.empty() && bad_closes==0;
 if(scenario=="failure_then_recover") {
   loader_success=true;
   int second=hsaKmtOpenKFD();
   pass=pass && second==HSAKMT_STATUS_SUCCESS && runtime.dxg_open_count==1 && live.count(runtime.dxg_fd)==1 && opens==2;
 }
 if(scenario=="healthy")pass=first==0 && runtime.dxg_open_count==1 && live.count(runtime.dxg_fd)==1 && opens==1 && closes==0 && resets==1;
 if(scenario=="open_failure")pass=first==2 && runtime.dxg_fd==-1 && runtime.dxg_open_count==0 && live.empty() && closes==0;
 if(scenario=="already_open")pass=first==3 && runtime.dxg_open_count==2 && runtime.dxg_fd==17 && opens==0 && closes==0 && resets==0;
 std::cout<<"{\"contract_pass\":"<<(pass?"true":"false")<<",\"stored_fd_reset_after_failure\":"<<(fd_after_first==-1?"true":"false")
 <<",\"first_status\":"<<first<<",\"opens\":"<<opens<<",\"closes\":"<<closes<<",\"invalid_fake_closes\":"<<bad_closes
 <<",\"stored_fd_live_at_end\":"<<(live.count(runtime.dxg_fd)?"true":"false")<<"}"<<std::endl;
}
'''
build=root/'build'
build.mkdir(exist_ok=True)
rows=[]
for variant,oid in pins.items():
    path=root/variant/'openclose.cpp'
    raw=path.read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
    text=raw.decode()
    start=text.index('HSAKMT_STATUS HSAKMTAPI hsaKmtOpenKFD(void)')
    end=text.index('\nHSAKMT_STATUS HSAKMTAPI hsaKmtCloseKFD(void)',start)
    function=text[start:end]
    source=build/(variant+'.cpp')
    source.write_text(text.split('#include',1)[0]+scaffold.replace('__FUNCTION__',function))
    binary=build/variant
    subprocess.run(['g++','-std=c++17','-O0','-pthread',str(source),'-o',str(binary)],check=True,capture_output=True,timeout=30)
    for scenario in ['healthy','open_failure','already_open','loader_failure','existing_fd_failure','failure_then_recover']:
        proc=subprocess.run([str(binary),scenario],check=True,capture_output=True,text=True,timeout=5)
        row=json.loads(proc.stdout)
        row.update(variant=variant,scenario=scenario)
        rows.append(row)
        assert row['contract_pass']==(variant=='proposed' or scenario in ['healthy','open_failure','already_open']),row
report={'scope':'actual extracted hsaKmtOpenKFD with fake OS descriptor table and fake DXCore loader; no AMD runtime, OS descriptor close, /dev/dxg, or GPU',
        'pins':pins,'fix_pr':'https://github.com/ROCm/rocm-systems/pull/10738',
        'pr_head':'06d49e43db342c6a73e87e55589e3da4ba201193','cases':rows,
        'baseline_failures':sum(not x['contract_pass'] for x in rows if x['variant']=='baseline'),
        'proposed_failures':sum(not x['contract_pass'] for x in rows if x['variant']=='proposed')}
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='cases'}))
