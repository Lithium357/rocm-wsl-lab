"""Actual DXG helpers and queue-create function, with inert allocation/queue objects."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

root=Path(__file__).resolve().parent
pins={'upstream-memory.cpp':'f66d0b982514f8b5d439ff3ebd4a317c3e9c126d',
      'upstream-queues.cpp':'f8fb999b8d0fa9d97f40ebc8c420177829c19a5a'}
texts={}
for filename,oid in pins.items():
    raw=(root/filename).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
    texts[filename]=raw.decode()
status=json.loads((root/'status-source.json').read_text())
error_value=int(re.search(r'HSAKMT_STATUS_ERROR\s*=\s*(\d+)',status['enum_line'])[1])
assert error_value==1
def extract(text,marker):
    first=text.index(marker)
    begin=text.index('{',first)
    depth,end=1,begin+1
    while depth:
        depth+=(text[end]=='{')-(text[end]=='}')
        end+=1
    return text[first:end]
helpers='\n'.join(extract(texts['upstream-memory.cpp'],'bool '+name+'(void *MemoryAddress)')
                  for name in ['queue_acquire_buffer','queue_release_buffer'])
create=extract(texts['upstream-queues.cpp'],'HSAKMT_STATUS HSAKMTAPI hsaKmtCreateQueueV2(')
assert helpers.count('return HSAKMT_STATUS_ERROR;')==2
patched_helpers=helpers.replace('return HSAKMT_STATUS_ERROR;','return false;')
patched_memory=texts['upstream-memory.cpp']
for name in ['queue_acquire_buffer','queue_release_buffer']:
    old=extract(patched_memory,'bool '+name+'(void *MemoryAddress)')
    patched_memory=patched_memory.replace(old,old.replace('return HSAKMT_STATUS_ERROR;','return false;'),1)
path='projects/rocr-runtime/libhsakmt/src/dxg/memory.cpp'
(root/'queue-reference-bool.patch').write_text(''.join(difflib.unified_diff(
    texts['upstream-memory.cpp'].splitlines(True),patched_memory.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
(root/'patched-memory.cpp').write_text(patched_memory)
scaffold=r'''
#include <atomic>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <map>
#include <mutex>
#include <string>
using HSAKMT_STATUS=int; using HSAuint32=uint32_t; using HSAuint64=uint64_t; using HSA_QUEUEID=uintptr_t;
using HSA_QUEUE_TYPE=int; using HSA_QUEUE_PRIORITY=int;
constexpr int HSAKMT_STATUS_SUCCESS=0,HSAKMT_STATUS_ERROR=__ERROR__,HSAKMT_STATUS_INVALID_PARAMETER=3;
constexpr int HSA_QUEUE_PRIORITY_MINIMUM=-3,HSA_QUEUE_PRIORITY_MAXIMUM=3;
constexpr int HSA_QUEUE_COMPUTE_AQL=1,HSA_QUEUE_SDMA=2,HSA_QUEUE_SDMA_BY_ENG_ID=3;
#define HSAKMTAPI
#define CHECK_DXG_OPEN() ((void)0)
#define pr_debug(...) ((void)0)
bool hsakmt_hsa_loader_init(){return true;}
int constructors=0;
namespace wsl { namespace thunk {
struct GpuMemory {
 int references=0;
 static GpuMemory* Convert(void* p){return static_cast<GpuMemory*>(p);}
 void GetQueueReference(){++references;}
 void PutQueueReference(){--references;}
};
struct WDDMDevice {
 uint32_t GetCmdbufSize(){return 64;} uint32_t GetComputeEngine(){return 0;}
 uint32_t GetSdmaEngine(int){return 0;} bool IsHwsEnabled(uint32_t){return false;}
};
struct ComputeQueue {
 template<class... A> explicit ComputeQueue(A...){++constructors;}
 void* GetDoorbellPtr(){return nullptr;}
};
struct SDMAQueue {
 template<class... A> explicit SDMAQueue(A...){++constructors;}
 void* GetDoorbellPtr(){return nullptr;} void* GetRingWptr(){return nullptr;} void* GetRingRptr(){return nullptr;}
};
}}
struct Allocation { void* handle; };
std::map<void*,Allocation> allocations;
auto* allocation_map_=&allocations;
std::mutex allocation_mutex;
auto* allocation_map_lock_=&allocation_mutex;
wsl::thunk::WDDMDevice* get_wddmdev(HSAuint32){static wsl::thunk::WDDMDevice dev;return &dev;}
struct HsaEvent {uint32_t EventId=0;};
struct HsaQueueResource {
 void* Queue_write_ptr_aql=nullptr; void* Queue_read_ptr_aql=nullptr; void* ErrorReason=nullptr;
 HSA_QUEUEID QueueId=0; void* Queue_DoorBell_aql=nullptr; void* Queue_DoorBell=nullptr;
};
__HELPERS__
__CREATE__
int main(int argc,char** argv){
 const std::string scenario=argv[1];
 char synthetic_buffer[64]={};
 wsl::thunk::GpuMemory memory;
 if(scenario=="registered_helpers" || scenario=="registered_queue")
   allocations[synthetic_buffer]={&memory};
 bool pass=false,observed=false;
 int status=-1;
 if(scenario=="null_helpers") pass=!queue_acquire_buffer(nullptr) && !queue_release_buffer(nullptr);
 if(scenario=="missing_acquire") {observed=queue_acquire_buffer(synthetic_buffer);pass=!observed && memory.references==0;}
 if(scenario=="missing_release") {observed=queue_release_buffer(synthetic_buffer);pass=!observed && memory.references==0;}
 if(scenario=="registered_helpers") {
   bool acquired=queue_acquire_buffer(synthetic_buffer);
   bool pinned=memory.references==1;
   bool released=queue_release_buffer(synthetic_buffer);
   pass=acquired && pinned && released && memory.references==0;
 }
 if(scenario=="missing_queue" || scenario=="registered_queue" || scenario=="null_queue"){
   HsaQueueResource resource;
   status=hsaKmtCreateQueueV2(1,HSA_QUEUE_COMPUTE_AQL,100,0,0,
     scenario=="null_queue"?nullptr:synthetic_buffer,64,0,nullptr,&resource);
   if(scenario=="registered_queue")
     pass=status==HSAKMT_STATUS_SUCCESS && constructors==1 && memory.references==1;
   else pass=status==HSAKMT_STATUS_INVALID_PARAMETER && constructors==0 && memory.references==0;
   if(resource.QueueId)delete reinterpret_cast<wsl::thunk::ComputeQueue*>(resource.QueueId);
   if(memory.references)queue_release_buffer(synthetic_buffer);
 }
 std::cout<<"{\"contract_pass\":"<<(pass?"true":"false")<<",\"helper_observed_true\":"<<(observed?"true":"false")
  <<",\"create_status\":"<<status<<",\"queue_constructors\":"<<constructors<<",\"remaining_references\":"<<memory.references<<"}"<<std::endl;
}
'''
build=root/'queue-reference-build'
build.mkdir(exist_ok=True)
results=[]
for variant,functions in [('upstream',helpers),('candidate',patched_helpers)]:
    code=scaffold.replace('__ERROR__',str(error_value)).replace('__HELPERS__',functions).replace('__CREATE__',create)
    source=build/(variant+'.cpp')
    source.write_text(texts['upstream-memory.cpp'].split('#include',1)[0]+code)
    binary=build/variant
    subprocess.run(['g++','-std=c++17','-O0','-Wall','-Wextra','-pthread',str(source),'-o',str(binary)],check=True,capture_output=True,timeout=30)
    for scenario in ['null_helpers','registered_helpers','null_queue','registered_queue','missing_acquire','missing_release','missing_queue']:
        proc=subprocess.run([str(binary),scenario],check=True,capture_output=True,text=True,timeout=5)
        result=json.loads(proc.stdout)
        result.update(variant=variant,scenario=scenario)
        results.append(result)
        assert result['contract_pass']==(variant=='candidate' or not scenario.startswith('missing_')),result
report={'scope':'actual extracted DXG queue helpers and hsaKmtCreateQueueV2; inert allocation map, reference counter, loader and queue constructors; no AMD runtime, GPU or OS device calls',
        'pins':pins,'status_source':status,'cases':results,
        'upstream_failures':sum(not r['contract_pass'] for r in results if r['variant']=='upstream'),
        'candidate_failures':sum(not r['contract_pass'] for r in results if r['variant']=='candidate')}
(root/'queue-reference-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='cases'}))
