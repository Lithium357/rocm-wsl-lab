# DXG queue-buffer Boolean regression

Run in a disposable Linux directory with Python 3 and g++:

```bash
python3 -I run_queue_reference_audit.py
```

Expected: upstream_failures=3 and candidate_failures=0, from seven scenarios
per variant. Source blob identities are verified before function extraction.
Only the Boolean missing-entry returns differ between upstream and candidate.

The real queue helpers and hsaKmtCreateQueueV2 are used. Native dependencies
are replaced by a private allocation map, reference counter, loader response,
and inert queue constructors. No actual AMD runtime, /dev/dxg, GPU operation,
production process or installed file is accessed. Test buffers are generated
stack arrays. Each case has a five-second subprocess deadline.

The patch is a candidate, not installed or published. Full upstream integration
and installed-runtime validation remain untested. This reproduces incorrect
Boolean validation and queue-constructor reachability in source; it does not
demonstrate a GPU crash, reset, or application data corruption.

Original upstream MIT license notices are retained in the source snapshots.
Build intermediates stay under queue-reference-build/. Results and the candidate
patch are regenerated beside the script.
